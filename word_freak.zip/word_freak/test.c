#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include "LList.h"

char load[15];
char buffer[100];

char convert(char a)
{
    if(a >= 97)
        return a;
    return a+32;
}

int strlenth(char *array)
{
    int i = 0;
    for(int j = 0; j < 10; j ++)
    {
        if(array[j] != ' ')
        {
            i ++;
        }
    }
    return i;
}

void printLList(struct Node *head)
{
    while(head->next != NULL)
    {
        printf("%s\n", head->name);
        printf("%i\n", head->count);
        printf("\n");
        head = head->next;
    }
}

void readstr(char * array, int length)
{
    for(int j = 0; j < length; j ++)
    {
        printf("%c", array[j]);
    }
    printf("\n");
}

void resetarray(char * array, int length)
{
    for(int i = 0; i < length; i ++)
    {
        array[i] = ' ';
    }
    
}

int checkExist(struct Node *head, char name[10])
{
    struct Node *current = head;
    while(current->next != NULL)
    {
        if(strcmp(current->name, name) == 0)
        {
            return 1;
        }
        current = current->next;
    }
    return 0;
}

void updateCount(struct Node *head, char name[10])
{
    struct Node *current = head;
    while(current->next != NULL)
    {
        if(strcmp(current->name, name) == 0)
        {
            current->count ++;
            return;
        }
        current = current->next;
    }
}

void updateList(struct Node *head, struct Node *tail, char *name)
{

    printf("%s\n", name);

    if(strcmp(head->name, "!DeFaUt!") == 0)
    {
        head->name = name;
        printf("%s\n", head->name);
        head->count ++;
        tail = head;
    }
    else
    {
        if(checkExist(head, name) == 1)
        {
            updateCount(head, name);
        }
        else
        {
            struct Node *newNode;
            newNode = node(name, 0, NULL);
            tail->next = newNode;
            tail = tail->next;
        }
    }
}

int main(int argc, char *argv[])
{
     struct Node *head;
     struct Node *tail;
     head = node("!DeFaUt!", 0, NULL);
     tail = head;
     resetarray(buffer, 100);
     resetarray(load, 15);
     int fd = open(argv[1], O_RDONLY);
     read(fd, buffer, 100);
     int count = 0;
     for(int k = 0; k < 100; k ++)
     {

        if(buffer[k] != ' ')// right now is not the space
        {   
            if(buffer[k] >= 'a' && buffer[k] <= 'z' || buffer[k] >= 'A' && buffer[k] <= 'Z')
            {
                if(*(load+count) == ' ')
                {
                    *(load + count) = convert(buffer[k]);
                  count ++;
                 }
            }
        }
        else// right now is the space,代表要么一个单词结束了， 或者还未开始是前面的空格
        {
            if(*load != ' ')
            {
                //printf("Printf result is: %s\n", load);
                updateList(head, tail, load);
                resetarray(load, 10);
                count = 0;
            }
        }
     }

     //printLList(head);
     return 0;
}

