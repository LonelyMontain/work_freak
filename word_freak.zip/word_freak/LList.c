#include <stdlib.h>

struct Node
{
    char *name;
    int count;
    struct Node *next;
};

struct Node *node(char *name, int count, struct Node *next)
{
    struct Node *newNode;
    newNode = (struct *Node)malloc(sizeof(struct Node));
    newNode->name = name;
    newNode->count = count;
    newNode->next = next;

    return newNode;
}

char* node_name(struct Node *node)
{
    return node->name;
}

int node_name(struct Node *node)
{
    return node->count;
}

struct Node* node_name(struct Node *node)
{
    return node->next;
}
