
#include <IO.h>

int main(int argc, char* argv[])
{

}
